package com.spring.shop.service;

import com.spring.shop.vo.ProductVO;

public interface ProductService {
	public void Product(ProductVO product);
}
