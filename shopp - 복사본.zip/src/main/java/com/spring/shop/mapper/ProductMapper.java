package com.spring.shop.mapper;

import com.spring.shop.vo.ProductVO;

public interface ProductMapper {

	public void Productenroll(ProductVO product);
	
	
}
